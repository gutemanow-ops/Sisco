package com.fastkeno.app.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.random.Random

@Singleton
class KenoRepository @Inject constructor() {

    private val _currentDraw = MutableStateFlow<KenoDraw?>(null)
    val currentDraw: StateFlow<KenoDraw?> = _currentDraw.asStateFlow()

    private val _drawHistory = MutableStateFlow<List<KenoDraw>>(emptyList())
    val drawHistory: StateFlow<List<KenoDraw>> = _drawHistory.asStateFlow()

    private val _userTickets = MutableStateFlow<List<KenoTicket>>(emptyList())
    val userTickets: StateFlow<List<KenoTicket>> = _userTickets.asStateFlow()

    private val _allTickets = MutableStateFlow<List<KenoTicket>>(emptyList())
    val allTickets: StateFlow<List<KenoTicket>> = _allTickets.asStateFlow()

    private val _userBalance = MutableStateFlow(0.36)
    val userBalance: StateFlow<Double> = _userBalance.asStateFlow()

    private val _numberFrequencies = MutableStateFlow<List<NumberFrequency>>(emptyList())
    val numberFrequencies: StateFlow<List<NumberFrequency>> = _numberFrequencies.asStateFlow()

    private val _leaderboard = MutableStateFlow<List<LeaderboardEntry>>(emptyList())
    val leaderboard: StateFlow<List<LeaderboardEntry>> = _leaderboard.asStateFlow()

    private val _timerSeconds = MutableStateFlow(60)
    val timerSeconds: StateFlow<Int> = _timerSeconds.asStateFlow()

    private val _isDrawing = MutableStateFlow(false)
    val isDrawing: StateFlow<Boolean> = _isDrawing.asStateFlow()

    private val drawHistoryList = mutableListOf<KenoDraw>()
    private val userId = "239251"

    init {
        generateMockHistory()
        generateMockLeaderboard()
        calculateFrequencies()
    }

    fun startNewDraw() {
        val drawId = generateDrawId()
        val serverSeed = generateServerSeed()
        val serverSeedHash = hashServerSeed(serverSeed)

        _currentDraw.value = KenoDraw(
            drawId = drawId,
            timestamp = System.currentTimeMillis(),
            numbers = emptyList(),
            serverSeedHash = serverSeedHash,
            clientSeed = generateClientSeed()
        )
        _timerSeconds.value = 60
        _isDrawing.value = false
    }

    fun placeBet(selectedNumbers: List<Int>, betAmount: Double): Result<KenoTicket> {
        if (selectedNumbers.isEmpty() || selectedNumbers.size > 10) {
            return Result.failure(IllegalArgumentException("Select 1-10 numbers"))
        }
        if (betAmount <= 0) {
            return Result.failure(IllegalArgumentException("Invalid bet amount"))
        }
        if (_userBalance.value < betAmount) {
            return Result.failure(IllegalStateException("Insufficient balance"))
        }

        val currentDrawId = _currentDraw.value?.drawId ?: generateDrawId()
        val potentialWin = PayoutTable.calculateWin(
            selectedNumbers.size,
            selectedNumbers.size,
            betAmount
        )

        val ticket = KenoTicket(
            userId = userId,
            drawId = currentDrawId,
            selectedNumbers = selectedNumbers.sorted(),
            betAmount = betAmount,
            potentialWin = potentialWin
        )

        _userBalance.value -= betAmount
        val currentTickets = _userTickets.value.toMutableList()
        currentTickets.add(ticket)
        _userTickets.value = currentTickets

        val allCurrent = _allTickets.value.toMutableList()
        allCurrent.add(ticket)
        _allTickets.value = allCurrent

        return Result.success(ticket)
    }

    fun executeDraw(): KenoDraw {
        val drawNumbers = generateDrawNumbers()
        val current = _currentDraw.value ?: KenoDraw(
            drawId = generateDrawId(),
            timestamp = System.currentTimeMillis(),
            numbers = drawNumbers,
            serverSeedHash = ""
        )

        val completedDraw = current.copy(
            numbers = drawNumbers,
            revealedServerSeed = generateServerSeed()
        )

        _currentDraw.value = completedDraw
        _isDrawing.value = true

        // Process tickets
        processTickets(completedDraw)

        // Add to history
        drawHistoryList.add(0, completedDraw)
        _drawHistory.value = drawHistoryList.toList()

        calculateFrequencies()
        startNewDraw()

        return completedDraw
    }

    private fun processTickets(draw: KenoDraw) {
        val updatedTickets = _userTickets.value.map { ticket ->
            if (ticket.drawId == draw.drawId && ticket.status == TicketStatus.PENDING) {
                val matched = ticket.selectedNumbers.intersect(draw.numbers.toSet()).toList()
                val winAmount = PayoutTable.calculateWin(
                    ticket.selectedNumbers.size,
                    matched.size,
                    ticket.betAmount
                )

                val newStatus = if (winAmount > 0) TicketStatus.WON else TicketStatus.LOST
                if (winAmount > 0) {
                    _userBalance.value += winAmount
                }

                ticket.copy(
                    status = newStatus,
                    matchedNumbers = matched,
                    actualWin = winAmount
                )
            } else {
                ticket
            }
        }
        _userTickets.value = updatedTickets
    }

    fun doubleBet(ticket: KenoTicket): Result<KenoTicket> {
        return placeBet(ticket.selectedNumbers, ticket.betAmount * 2)
    }

    fun getTicketById(id: String): KenoTicket? {
        return _userTickets.value.find { it.id == id }
    }

    fun getDrawsForLast100(): List<KenoDraw> {
        return drawHistoryList.take(100)
    }

    private fun generateDrawNumbers(): List<Int> {
        return (1..80).shuffled().take(20).sorted()
    }

    private fun generateDrawId(): String {
        return (System.currentTimeMillis() / 1000).toString() + Random.nextInt(1000, 9999)
    }

    private fun generateServerSeed(): String {
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        return (1..64).map { chars.random() }.joinToString("")
    }

    private fun generateClientSeed(): String {
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        return (1..16).map { chars.random() }.joinToString("")
    }

    private fun hashServerSeed(seed: String): String {
        // Simplified hash for demo - in production use actual SHA-512
        return seed.hashCode().toString(16).padStart(64, '0')
    }

    private fun generateMockHistory() {
        val mockDraws = listOf(
            listOf(65, 44, 30, 24, 55, 60, 17, 79, 71, 31, 76, 49, 13, 25, 29, 35, 22, 39, 69, 45),
            listOf(34, 27, 17, 7, 49, 79, 1, 43, 28, 44, 32, 73, 2, 29, 3, 38, 15, 42, 67, 8),
            listOf(65, 25, 51, 45, 58, 74, 35, 66, 5, 39, 6, 38, 11, 27, 37, 20, 79, 13, 64, 9),
            listOf(22, 20, 21, 46, 29, 33, 25, 72, 30, 62, 12, 19, 74, 61, 69, 51, 8, 24, 10, 55),
            listOf(47, 68, 76, 5, 79, 45, 12, 30, 10, 70, 46, 65, 16, 54, 23, 60, 44, 18, 27, 9),
            listOf(55, 52, 5, 76, 14, 75, 68, 23, 33, 28, 80, 8, 21, 38, 30, 19, 9, 66, 48, 74),
            listOf(50, 52, 71, 11, 76, 69, 40, 27, 28, 2, 37, 61, 66, 7, 44, 75, 8, 4, 47, 55)
        )

        mockDraws.forEachIndexed { index, numbers ->
            val draw = KenoDraw(
                drawId = (884644000 + index * 100).toString(),
                timestamp = System.currentTimeMillis() - index * 120000,
                numbers = numbers,
                serverSeedHash = generateServerSeed(),
                revealedServerSeed = generateServerSeed()
            )
            drawHistoryList.add(draw)
        }
        _drawHistory.value = drawHistoryList.toList()
    }

    private fun generateMockLeaderboard() {
        val entries = listOf(
            LeaderboardEntry(1, "4***7", 10000.0, 500000.0),
            LeaderboardEntry(2, "1***5", 10000.0, 500000.0),
            LeaderboardEntry(3, "5***1", 10000.0, 500000.0),
            LeaderboardEntry(4, "5***2", 10000.0, 500000.0),
            LeaderboardEntry(5, "4***9", 10000.0, 500000.0),
            LeaderboardEntry(6, "1***5", 10000.0, 500000.0),
            LeaderboardEntry(7, "4***8", 600.0, 500000.0),
            LeaderboardEntry(8, "5***1", 10000.0, 500000.0),
            LeaderboardEntry(9, "6***2", 20000.0, 500000.0),
            LeaderboardEntry(10, "2***7", 10000.0, 500000.0)
        )
        _leaderboard.value = entries
    }

    private fun calculateFrequencies() {
        val allNumbers = drawHistoryList.flatMap { it.numbers }
        val frequencyMap = allNumbers.groupingBy { it }.eachCount()

        val maxFreq = frequencyMap.values.maxOrNull() ?: 0
        val minFreq = frequencyMap.values.minOrNull() ?: 0
        val threshold = (maxFreq + minFreq) / 2

        val frequencies = (1..80).map { num ->
            val freq = frequencyMap[num] ?: 0
            NumberFrequency(
                number = num,
                frequency = freq,
                isHot = freq > threshold,
                isCold = freq < threshold && freq > 0
            )
        }
        _numberFrequencies.value = frequencies
    }
}
