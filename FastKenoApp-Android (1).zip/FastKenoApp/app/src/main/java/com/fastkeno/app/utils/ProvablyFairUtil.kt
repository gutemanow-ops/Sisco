package com.fastkeno.app.utils

import java.security.MessageDigest
import java.security.SecureRandom

object ProvablyFairUtil {

    fun generateServerSeed(): String {
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        val random = SecureRandom()
        return (1..64).map { chars[random.nextInt(chars.length)] }.joinToString("")
    }

    fun generateClientSeed(): String {
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        val random = SecureRandom()
        return (1..16).map { chars[random.nextInt(chars.length)] }.joinToString("")
    }

    fun hashWithSHA512(input: String): String {
        val digest = MessageDigest.getInstance("SHA-512")
        val hashBytes = digest.digest(input.toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    fun hashWithSHA256(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(input.toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    fun generateKenoNumbers(serverSeed: String, clientSeed: String, nonce: Int): List<Int> {
        val combined = "${'$'}serverSeed:${'$'}clientSeed:${'$'}nonce"
        val hash = hashWithSHA512(combined)

        val numbers = mutableSetOf<Int>()
        var index = 0

        while (numbers.size < 20 && index + 4 <= hash.length) {
            val chunk = hash.substring(index, index + 4)
            val value = chunk.toIntOrNull(16) ?: 0
            val number = (value % 80) + 1
            numbers.add(number)
            index += 4
        }

        // Fallback if not enough unique numbers
        while (numbers.size < 20) {
            val remaining = (1..80).filter { it !in numbers }
            if (remaining.isNotEmpty()) {
                numbers.add(remaining.random())
            }
        }

        return numbers.sorted()
    }

    fun verifyFairness(
        serverSeed: String,
        clientSeed: String,
        nonce: Int,
        expectedNumbers: List<Int>
    ): Boolean {
        val generated = generateKenoNumbers(serverSeed, clientSeed, nonce)
        return generated == expectedNumbers.sorted()
    }

    fun createKey(roundId: String, numbers: List<Int>, randomSequence: String): String {
        return "${'$'}{roundId}_numbers_${'$'}{numbers.joinToString(",")}_Keno_${'$'}randomSequence"
    }
}
