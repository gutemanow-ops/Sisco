package com.fastkeno.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun RulesScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "RULES",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        InfoCard {
            Text(
                text = "RTP: 97%",
                color = Color(0xFF4ADE80),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Max Win - 80000 ETB",
                color = Color(0xFFFBBF24),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        InfoCard {
            Text(
                text = "How to Play",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                text = "Keno is a game where the player bets on balls numbered 1-80 by choosing a combination from balls numbered 1 to 10.",
                color = Color(0xFF9CA3AF),
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "During each round, 20 of the balls numbered from 1-80 are drawn in sequence using a random number generator.",
                color = Color(0xFF9CA3AF),
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        InfoCard {
            Text(
                text = "To participate in the game, the player must perform the following actions during the round, which lasts one minute:",
                color = Color(0xFF9CA3AF),
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            BulletPoint("Choose the combination of numbers")
            BulletPoint("Set the amount limit for betting")
            BulletPoint("Click the "Bet" button")
        }

        Spacer(modifier = Modifier.height(16.dp))

        InfoCard {
            Text(
                text = "HOT and COLD numbers are indicated in red and blue colors, with hot numbers being those that are frequently drawn and blue being those that are drawn more infrequently.",
                color = Color(0xFF9CA3AF),
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Payout table
        InfoCard {
            Text(
                text = "Payout Table",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            PayoutTable()
        }

        Spacer(modifier = Modifier.height(16.dp))

        InfoCard {
            Text(
                text = "Disconnection Policy",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                text = "If a disconnection occurs after an active game round and your bets were accepted by the server, the game will proceed as normal and any winnings will be processed according to the game result regardless of the disconnection.",
                color = Color(0xFF9CA3AF),
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
        }
    }
}

@Composable
fun InfoCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF1A2E1A), RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        content()
    }
}

@Composable
fun BulletPoint(text: String) {
    Row(
        modifier = Modifier.padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("•", color = MaterialTheme.colorScheme.primary, fontSize = 16.sp)
        Text(text, color = Color(0xFF9CA3AF), fontSize = 14.sp)
    }
}

@Composable
fun PayoutTable() {
    val payouts = listOf(
        listOf("", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"),
        listOf("0", "", "", "", "", "", "", "1", "1", "2", "2"),
        listOf("1", "3.5", "1", "", "", "", "", "", "", "", ""),
        listOf("2", "", "10", "2", "1.5", "1", "", "", "", "", ""),
        listOf("3", "", "", "50", "10", "3", "2", "2", "", "", ""),
        listOf("4", "", "", "", "80", "30", "15", "4", "5", "2", ""),
        listOf("5", "", "", "", "", "150", "60", "20", "15", "10", "5"),
        listOf("6", "", "", "", "", "", "500", "80", "50", "25", "30"),
        listOf("7", "", "", "", "", "", "", "1000", "200", "125", "100"),
        listOf("8", "", "", "", "", "", "", "", "2000", "1000", "300"),
        listOf("9", "", "", "", "", "", "", "", "", "5000", "2000"),
        listOf("10", "", "", "", "", "", "", "", "", "", "10000")
    )

    Column {
        payouts.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                row.forEach { cell ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                if (cell.isNotEmpty() && cell != "") Color(0xFF2D3748) else Color.Transparent
                            )
                            .padding(4.dp),
                        contentAlignment = androidx.compose.ui.Alignment.Center
                    ) {
                        Text(
                            text = cell,
                            color = if (cell.isNotEmpty() && cell != "") Color.White else Color(0xFF9CA3AF),
                            fontSize = 10.sp,
                            fontWeight = if (cell.isNotEmpty() && cell != "") FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}
