package com.fastkeno.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fastkeno.app.viewmodel.KenoViewModel

@Composable
fun WithdrawScreen(
    viewModel: KenoViewModel
) {
    var amount by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    val userBalance by viewModel.userBalance.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text(
            text = "WITHDRAW",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        // Balance display
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1A3A1A), RoundedCornerShape(12.dp))
                .padding(20.dp)
        ) {
            Column {
                Text(
                    text = "Available Balance",
                    color = Color(0xFF9CA3AF),
                    fontSize = 14.sp
                )
                Text(
                    text = String.format("%.2f ETB", userBalance),
                    color = Color(0xFFFBBF24),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Amount",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 14.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        OutlinedTextField(
            value = amount,
            onValueChange = { amount = it.filter { c -> c.isDigit() } },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = Color(0xFF4A5568),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            suffix = { Text("ETB", color = Color(0xFF9CA3AF)) }
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Telebirr Phone Number",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 14.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        OutlinedTextField(
            value = phoneNumber,
            onValueChange = { phoneNumber = it.filter { c -> c.isDigit() }.take(10) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = Color(0xFF4A5568),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            placeholder = { Text("09XXXXXXXX", color = Color(0xFF4A5568)) }
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { /* Process withdrawal */ },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF22C55E)
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                text = "Withdraw",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
