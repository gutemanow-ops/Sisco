package com.fastkeno.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fastkeno.app.data.KenoTicket
import com.fastkeno.app.data.TicketStatus
import com.fastkeno.app.ui.components.NumberGrid
import com.fastkeno.app.ui.components.TicketCard
import com.fastkeno.app.ui.components.TimerComponent
import com.fastkeno.app.viewmodel.KenoViewModel
import com.fastkeno.app.viewmodel.Screen

@Composable
fun GameScreen(
    viewModel: KenoViewModel
) {
    val selectedNumbers by viewModel.selectedNumbers.collectAsState()
    val currentBet by viewModel.currentBet.collectAsState()
    val userBalance by viewModel.userBalance.collectAsState()
    val timerSeconds by viewModel.timerSeconds.collectAsState()
    val userTickets by viewModel.userTickets.collectAsState()
    val allTickets by viewModel.allTickets.collectAsState()
    val currentDraw by viewModel.currentDraw.collectAsState()
    val isDrawing by viewModel.isDrawing.collectAsState()
    val numberFrequencies by viewModel.numberFrequencies.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    val showWinDialog by viewModel.showWinDialog.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header with balance and ID
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                BalanceChip(balance = userBalance)
                UserIdChip(userId = "239251")
            }
        }

        // Timer
        item {
            TimerComponent(
                secondsRemaining = timerSeconds,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }

        // Drawn balls display
        item {
            if (currentDraw?.numbers?.isNotEmpty() == true) {
                DrawnBallsDisplay(numbers = currentDraw.numbers)
            }
        }

        // Number selection info
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Choose ${'$'}{selectedNumbers.size}/10 numbers",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp
                )
                Text(
                    text = "From 1 to 80",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 14.sp
                )
            }
        }

        // Number Grid
        item {
            NumberGrid(
                selectedNumbers = selectedNumbers,
                drawnNumbers = currentDraw?.numbers ?: emptyList(),
                numberFrequencies = numberFrequencies,
                onNumberClick = { viewModel.selectNumber(it) },
                modifier = Modifier.height(420.dp)
            )
        }

        // Quick actions
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { viewModel.quickPick() },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF1A3A1A)
                    )
                ) {
                    Text("Quick Pick", color = MaterialTheme.colorScheme.primary)
                }
                Button(
                    onClick = { viewModel.clearSelection() },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF3A1A1A)
                    )
                ) {
                    Text("Clear", color = Color(0xFFEF4444))
                }
            }
        }

        // Bet controls
        item {
            BetControls(
                currentBet = currentBet,
                onAdjustBet = { viewModel.adjustBet(it) },
                onDouble = { viewModel.doubleBet() },
                onMax = { viewModel.setBet(10000.0) }
            )
        }

        // BET Button
        item {
            Button(
                onClick = { viewModel.placeBet() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF22C55E)
                ),
                shape = RoundedCornerShape(12.dp),
                enabled = selectedNumbers.isNotEmpty() && !isDrawing
            ) {
                Text(
                    text = "BET",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }

        // Tickets header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "All ${'$'}{allTickets.size}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp
                )
                Text(
                    text = "My Tickets ${'$'}{userTickets.size}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp
                )
                Text(
                    text = "My Bets ${'$'}{userTickets.filter { it.status == TicketStatus.PENDING }.size}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp
                )
            }
        }

        // Active tickets
        items(userTickets.take(10)) { ticket ->
            TicketCard(ticket = ticket)
        }
    }

    // Error dialog
    errorMessage?.let { message ->
        AlertDialog(
            onDismissRequest = { viewModel.clearError() },
            title = { Text("Error") },
            text = { Text(message) },
            confirmButton = {
                TextButton(onClick = { viewModel.clearError() }) {
                    Text("OK")
                }
            }
        )
    }

    // Win dialog
    showWinDialog?.let { ticket ->
        WinDialog(
            ticket = ticket,
            onDismiss = { viewModel.dismissWinDialog() }
        )
    }
}

@Composable
fun BalanceChip(balance: Double) {
    Box(
        modifier = Modifier
            .background(
                color = Color(0xFF1A3A1A),
                shape = RoundedCornerShape(20.dp)
            )
            .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(20.dp))
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = String.format("%.2f ETB", balance),
            color = Color(0xFFFBBF24),
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
        )
    }
}

@Composable
fun UserIdChip(userId: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "ID: $userId",
            color = MaterialTheme.colorScheme.onSurface,
            fontSize = 14.sp
        )
        Box(
            modifier = Modifier
                .size(24.dp)
                .background(MaterialTheme.colorScheme.primary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text("✓", color = Color.Black, fontSize = 12.sp)
        }
    }
}

@Composable
fun DrawnBallsDisplay(numbers: List<Int>) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0A1A0A), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            numbers.forEach { number ->
                DrawnBall(number = number)
            }
        }
    }
}

@Composable
fun DrawnBall(number: Int) {
    Box(
        modifier = Modifier
            .size(36.dp)
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF3D4F3D), Color(0xFF1A2E1A))
                ),
                CircleShape
            )
            .border(2.dp, Color(0xFF4A5568), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = number.toString(),
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun BetControls(
    currentBet: Double,
    onAdjustBet: (Double) -> Unit,
    onDouble: () -> Unit,
    onMax: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Bet amount adjuster
        Row(
            modifier = Modifier
                .weight(1f)
                .background(Color(0xFF2D3748), RoundedCornerShape(8.dp))
                .padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { onAdjustBet(-1.0) }) {
                Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = Color.White)
            }
            Text(
                text = currentBet.toInt().toString(),
                modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            IconButton(onClick = { onAdjustBet(1.0) }) {
                Icon(Icons.Default.Add, contentDescription = "Increase", tint = Color.White)
            }
        }

        Button(
            onClick = onDouble,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A3A1A)),
            modifier = Modifier.width(60.dp)
        ) {
            Text("X2", color = MaterialTheme.colorScheme.primary)
        }

        Button(
            onClick = onMax,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A3A1A)),
            modifier = Modifier.width(60.dp)
        ) {
            Text("MAX", color = MaterialTheme.colorScheme.primary, fontSize = 10.sp)
        }
    }
}

@Composable
fun WinDialog(
    ticket: KenoTicket,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "🎉 CONGRATULATIONS!",
                color = Color(0xFF4ADE80),
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "You won!",
                    fontSize = 18.sp,
                    color = Color.White
                )
                Text(
                    text = String.format("%.0f ETB", ticket.actualWin ?: 0.0),
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFBBF24)
                )
                Text(
                    text = "Matched ${'$'}{ticket.matchedNumbers.size} numbers",
                    color = Color(0xFF9CA3AF)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E))
            ) {
                Text("AWESOME!")
            }
        },
        containerColor = Color(0xFF1A2E1A)
    )
}

// FlowRow implementation for Compose
@Composable
fun FlowRow(
    modifier: Modifier = Modifier,
    horizontalArrangement: Arrangement.Horizontal = Arrangement.Start,
    verticalArrangement: Arrangement.Vertical = Arrangement.Top,
    content: @Composable () -> Unit
) {
    Layout(
        content = content,
        modifier = modifier
    ) { measurables, constraints ->
        val hGapPx = 6.dp.roundToPx()
        val vGapPx = 6.dp.roundToPx()
        val rows = mutableListOf<List<androidx.compose.ui.layout.Placeable>>()
        val rowWidths = mutableListOf<Int>()
        val rowHeights = mutableListOf<Int>()

        var currentRow = mutableListOf<androidx.compose.ui.layout.Placeable>()
        var currentRowWidth = 0
        var currentRowHeight = 0

        measurables.forEach { measurable ->
            val placeable = measurable.measure(constraints)

            if (currentRow.isNotEmpty() &&
                currentRowWidth + hGapPx + placeable.width > constraints.maxWidth
            ) {
                rows.add(currentRow)
                rowWidths.add(currentRowWidth)
                rowHeights.add(currentRowHeight)
                currentRow = mutableListOf()
                currentRowWidth = 0
                currentRowHeight = 0
            }

            currentRow.add(placeable)
            currentRowWidth += if (currentRow.size == 1) placeable.width else hGapPx + placeable.width
            currentRowHeight = maxOf(currentRowHeight, placeable.height)
        }

        if (currentRow.isNotEmpty()) {
            rows.add(currentRow)
            rowWidths.add(currentRowWidth)
            rowHeights.add(currentRowHeight)
        }

        val totalHeight = rowHeights.sum() + (rows.size - 1) * vGapPx

        layout(constraints.maxWidth, totalHeight) {
            var y = 0
            rows.forEachIndexed { rowIndex, row ->
                var x = when (horizontalArrangement) {
                    Arrangement.Center -> (constraints.maxWidth - rowWidths[rowIndex]) / 2
                    Arrangement.End -> constraints.maxWidth - rowWidths[rowIndex]
                    else -> 0
                }

                row.forEach { placeable ->
                    placeable.placeRelative(x, y)
                    x += placeable.width + hGapPx
                }
                y += rowHeights[rowIndex] + vGapPx
            }
        }
    }
}
