package com.fastkeno.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class FastKenoApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
