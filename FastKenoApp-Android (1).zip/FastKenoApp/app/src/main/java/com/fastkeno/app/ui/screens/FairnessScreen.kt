package com.fastkeno.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun FairnessScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "FAIRNESS",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        InfoCard {
            Text(
                text = "What is "Salt"",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                text = "It is a random sequence of letters and numbers. For instance: e20d4c76c654.",
                color = Color(0xFF9CA3AF),
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        InfoCard {
            Text(
                text = "What is "Key"",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                text = "A text combination of four parameters:",
                color = Color(0xFF9CA3AF),
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            BulletPoint("1. Round Id")
            BulletPoint("2. The outcome numbers")
            BulletPoint("3. Wording "Keno"")
            BulletPoint("4. A random sequence of letters and numbers")
        }

        Spacer(modifier = Modifier.height(16.dp))

        InfoCard {
            Text(
                text = "How it works",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                text = "After the end of a game, the player will see the Key in his betting history. If we encrypt the "Key" via the "Salt" using the SHA512 generator, we'll get the defined Hash code.",
                color = Color(0xFF9CA3AF),
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "To get a hash code you can click on check icon in Result section and perform the check. You can get the encryption "Key" and "Hash Code" below or check on any online server that has a generator SHA512 With Salt.",
                color = Color(0xFF9CA3AF),
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        InfoCard {
            Text(
                text = "Example Hash",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Text(
                text = "3586ED7EECC3AEA4A6AC4A359D96E5CF30BBC47E24ED9E030066D7C7DE6C82B1F1376122E35B5165342F27243E1BE5B46B31F2A5D97E6DE26E0E4A6202DF3CDD",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 12.sp,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                lineHeight = 16.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        InfoCard {
            Text(
                text = "Verification Steps",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            BulletPoint("Copy the Server Seed (Salt) from game history")
            BulletPoint("Copy the Client Seed and Nonce")
            BulletPoint("Use any SHA-512 online generator")
            BulletPoint("Verify the hash matches the published result")
            BulletPoint("Confirm the drawn numbers are correct")
        }
    }
}
