package com.fastkeno.app

import com.fastkeno.app.data.KenoRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideKenoRepository(): KenoRepository {
        return KenoRepository()
    }
}
