package com.fastkeno.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fastkeno.app.data.LeaderboardEntry
import com.fastkeno.app.viewmodel.KenoViewModel

@Composable
fun LeadersScreen(
    viewModel: KenoViewModel
) {
    val leaderboard by viewModel.leaderboard.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text(
            text = "🏆 Leaderboard",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Header row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("#", color = Color(0xFF9CA3AF), fontSize = 12.sp, modifier = Modifier.width(30.dp))
            Text("ID", color = Color(0xFF9CA3AF), fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text("Bet", color = Color(0xFF9CA3AF), fontSize = 12.sp, modifier = Modifier.width(80.dp))
            Text("Win", color = Color(0xFF9CA3AF), fontSize = 12.sp, modifier = Modifier.width(100.dp))
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(leaderboard) { entry ->
                LeaderboardRow(entry = entry)
            }
        }

        // Fairness badge
        Spacer(modifier = Modifier.height(24.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1A2E1A), RoundedCornerShape(12.dp))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(Color(0xFF4ADE80), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("✓", color = Color.Black, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                    text = "FAIRNESS",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "ATLAS-V GAMING",
                    color = Color(0xFF9CA3AF),
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
fun LeaderboardRow(entry: LeaderboardEntry) {
    val rankColor = when (entry.rank) {
        1 -> Color(0xFFFBBF24)
        2 -> Color(0xFFC0C0C0)
        3 -> Color(0xFFCD7F32)
        else -> Color(0xFF9CA3AF)
    }

    val backgroundColor = when (entry.rank) {
        1 -> Color(0xFF1A3A1A)
        2, 3 -> Color(0xFF1A2E1A)
        else -> Color(0xFF0D1F0D)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(backgroundColor, RoundedCornerShape(8.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = entry.rank.toString(),
            color = rankColor,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.width(30.dp)
        )
        Text(
            text = entry.userId,
            color = MaterialTheme.colorScheme.primary,
            fontSize = 14.sp,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = String.format("%,.0f", entry.betAmount),
            color = Color.White,
            fontSize = 14.sp,
            modifier = Modifier.width(80.dp)
        )
        Text(
            text = String.format("%,.0f ETB", entry.winAmount),
            color = Color(0xFF4ADE80),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.width(100.dp)
        )
    }
}
