package com.fastkeno.app.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fastkeno.app.data.NumberFrequency

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NumberGrid(
    selectedNumbers: Set<Int>,
    drawnNumbers: List<Int> = emptyList(),
    matchedNumbers: List<Int> = emptyList(),
    numberFrequencies: List<NumberFrequency> = emptyList(),
    onNumberClick: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val frequencyMap = numberFrequencies.associateBy { it.number }

    LazyVerticalGrid(
        columns = GridCells.Fixed(10),
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items((1..80).toList()) { number ->
            val freq = frequencyMap[number]
            val isSelected = number in selectedNumbers
            val isDrawn = number in drawnNumbers
            val isMatched = number in matchedNumbers
            val isHot = freq?.isHot == true
            val isCold = freq?.isCold == true

            NumberCell(
                number = number,
                isSelected = isSelected,
                isDrawn = isDrawn,
                isMatched = isMatched,
                isHot = isHot,
                isCold = isCold,
                onClick = { onNumberClick(number) }
            )
        }
    }
}

@Composable
private fun NumberCell(
    number: Int,
    isSelected: Boolean,
    isDrawn: Boolean,
    isMatched: Boolean,
    isHot: Boolean,
    isCold: Boolean,
    onClick: () -> Unit
) {
    val backgroundColor = when {
        isMatched -> Color(0xFF4ADE80)
        isSelected -> Color(0xFF4ADE80)
        isHot -> Color(0xFFEF4444)
        isCold -> Color(0xFF3B82F6)
        else -> Color(0xFF2D3748)
    }

    val textColor = when {
        isMatched || isSelected -> Color.Black
        else -> Color.White
    }

    val borderColor = when {
        isMatched -> Color(0xFF22C55E)
        isSelected -> Color(0xFF22C55E)
        isHot -> Color(0xFFEF4444)
        isCold -> Color(0xFF3B82F6)
        else -> Color(0xFF4A5568)
    }

    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .clickable(onClick = onClick)
            .background(backgroundColor, MaterialTheme.shapes.small)
            .border(1.dp, borderColor, MaterialTheme.shapes.small),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = number.toString(),
            color = textColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
