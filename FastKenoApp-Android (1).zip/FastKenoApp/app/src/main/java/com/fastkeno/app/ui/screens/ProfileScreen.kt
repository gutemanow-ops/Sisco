package com.fastkeno.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fastkeno.app.viewmodel.KenoViewModel
import com.fastkeno.app.viewmodel.Screen

@Composable
fun ProfileScreen(
    viewModel: KenoViewModel
) {
    val userBalance by viewModel.userBalance.collectAsState()
    val userTickets by viewModel.userTickets.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Profile header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1A2E1A))
                .padding(24.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .background(MaterialTheme.colorScheme.primary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "U",
                        color = Color.Black,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "User 239251",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = String.format("%.2f ETB", userBalance),
                    color = Color(0xFFFBBF24),
                    fontSize = 18.sp
                )
            }
        }

        // Menu items
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MenuItem(
                icon = Icons.Default.History,
                title = "BET HISTORY",
                onClick = { viewModel.navigateTo(Screen.HISTORY) }
            )
            MenuItem(
                icon = Icons.Default.AccountBalance,
                title = "DEPOSIT",
                onClick = { viewModel.navigateTo(Screen.DEPOSIT) }
            )
            MenuItem(
                icon = Icons.Default.MoneyOff,
                title = "WITHDRAW",
                onClick = { viewModel.navigateTo(Screen.WITHDRAW) }
            )
            MenuItem(
                icon = Icons.Default.Receipt,
                title = "TRANSACTION HISTORY",
                onClick = { /* */ }
            )
            MenuItem(
                icon = Icons.Default.Info,
                title = "RULES",
                onClick = { viewModel.navigateTo(Screen.RULES) }
            )
            MenuItem(
                icon = Icons.Default.Verified,
                title = "FAIRNESS",
                onClick = { viewModel.navigateTo(Screen.FAIRNESS) }
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { /* Sign out */ },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF3A1A1A)
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "SIGN OUT",
                    color = Color(0xFFEF4444),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun MenuItem(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF1A2E1A), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
        )
        Text(
            text = title,
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
