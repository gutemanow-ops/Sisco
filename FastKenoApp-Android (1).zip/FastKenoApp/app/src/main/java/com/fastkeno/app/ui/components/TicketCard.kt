package com.fastkeno.app.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fastkeno.app.data.KenoTicket
import com.fastkeno.app.data.TicketStatus

@Composable
fun TicketCard(
    ticket: KenoTicket,
    modifier: Modifier = Modifier
) {
    val backgroundColor = when (ticket.status) {
        TicketStatus.WON -> Color(0xFF1A3A1A)
        TicketStatus.LOST -> Color(0xFF2D1A1A)
        else -> Color(0xFF1A2E1A)
    }

    val borderColor = when (ticket.status) {
        TicketStatus.WON -> Color(0xFF4ADE80)
        TicketStatus.LOST -> Color(0xFFEF4444)
        else -> Color(0xFF4A5568)
    }

    val statusColor = when (ticket.status) {
        TicketStatus.WON -> Color(0xFF4ADE80)
        TicketStatus.LOST -> Color(0xFFEF4444)
        else -> Color(0xFFFBBF24)
    }

    val statusText = when (ticket.status) {
        TicketStatus.WON -> "WIN ${'$'}{ticket.actualWin?.toInt() ?: 0}"
        TicketStatus.LOST -> "LOST"
        else -> "Waiting"
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(backgroundColor, RoundedCornerShape(12.dp))
            .border(1.dp, borderColor, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Text(
            text = ticket.getMaskedId(),
            color = Color(0xFF4ADE80),
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.padding(bottom = 8.dp)
        ) {
            ticket.selectedNumbers.forEach { number ->
                val isMatched = number in ticket.matchedNumbers
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(
                            if (isMatched) Color(0xFF4ADE80) else Color(0xFF4A5568),
                            RoundedCornerShape(8.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = number.toString(),
                        color = if (isMatched) Color.Black else Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Bet ${ticket.betAmount.toInt()}",
                color = Color(0xFF9CA3AF),
                fontSize = 14.sp
            )
            Text(
                text = statusText,
                color = statusColor,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
