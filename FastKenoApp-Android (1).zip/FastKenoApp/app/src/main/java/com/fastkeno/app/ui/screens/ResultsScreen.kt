package com.fastkeno.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fastkeno.app.data.KenoDraw
import com.fastkeno.app.viewmodel.KenoViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ResultsScreen(
    viewModel: KenoViewModel
) {
    val drawHistory by viewModel.drawHistory.collectAsState()
    val currentDraw by viewModel.currentDraw.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text(
            text = "Draw Results",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Current draw
        currentDraw?.let { draw ->
            if (draw.numbers.isEmpty()) {
                CurrentDrawWaiting(drawId = draw.drawId)
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(drawHistory) { draw ->
                ResultItem(draw = draw)
            }
        }
    }
}

@Composable
fun CurrentDrawWaiting(drawId: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF1A3A1A), RoundedCornerShape(8.dp))
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("✓", color = Color.Black, fontSize = 12.sp)
            }
            Text(
                text = drawId,
                color = MaterialTheme.colorScheme.primary,
                fontSize = 14.sp
            )
        }
        Text(
            text = "WAIT",
            color = Color(0xFF9CA3AF),
            fontSize = 14.sp
        )
    }
}

@Composable
fun ResultItem(draw: KenoDraw) {
    val dateFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    val time = dateFormat.format(Date(draw.timestamp))

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF1A2E1A), RoundedCornerShape(8.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(4.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("✓", color = Color.Black, fontSize = 12.sp)
                }
                Column {
                    Text(
                        text = draw.drawId,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 14.sp
                    )
                    Text(
                        text = time,
                        color = Color(0xFF9CA3AF),
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Numbers grid
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            NumberRow(numbers = draw.numbers.take(10))
            NumberRow(numbers = draw.numbers.drop(10).take(10))
        }
    }
}

@Composable
fun NumberRow(numbers: List<Int>) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        numbers.forEach { number ->
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(Color(0xFF2D3748), RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = number.toString(),
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
