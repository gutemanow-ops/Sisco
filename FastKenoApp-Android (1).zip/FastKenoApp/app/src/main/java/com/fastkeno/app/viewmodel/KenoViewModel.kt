package com.fastkeno.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fastkeno.app.data.KenoDraw
import com.fastkeno.app.data.KenoRepository
import com.fastkeno.app.data.KenoTicket
import com.fastkeno.app.data.LeaderboardEntry
import com.fastkeno.app.data.NumberFrequency
import com.fastkeno.app.data.TicketStatus
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class KenoViewModel @Inject constructor(
    private val repository: KenoRepository
) : ViewModel() {

    val currentDraw: StateFlow<KenoDraw?> = repository.currentDraw
    val drawHistory: StateFlow<List<KenoDraw>> = repository.drawHistory
    val userTickets: StateFlow<List<KenoTicket>> = repository.userTickets
    val allTickets: StateFlow<List<KenoTicket>> = repository.allTickets
    val userBalance: StateFlow<Double> = repository.userBalance
    val numberFrequencies: StateFlow<List<NumberFrequency>> = repository.numberFrequencies
    val leaderboard: StateFlow<List<LeaderboardEntry>> = repository.leaderboard
    val timerSeconds: StateFlow<Int> = repository.timerSeconds
    val isDrawing: StateFlow<Boolean> = repository.isDrawing

    private val _selectedNumbers = MutableStateFlow<Set<Int>>(emptySet())
    val selectedNumbers: StateFlow<Set<Int>> = _selectedNumbers.asStateFlow()

    private val _currentBet = MutableStateFlow(2.0)
    val currentBet: StateFlow<Double> = _currentBet.asStateFlow()

    private val _currentScreen = MutableStateFlow(Screen.GAME)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _showWinDialog = MutableStateFlow<KenoTicket?>(null)
    val showWinDialog: StateFlow<KenoTicket?> = _showWinDialog.asStateFlow()

    private var timerJob: Job? = null

    init {
        startTimer()
        repository.startNewDraw()
    }

    fun selectNumber(number: Int) {
        val current = _selectedNumbers.value.toMutableSet()
        if (current.contains(number)) {
            current.remove(number)
        } else if (current.size < 10) {
            current.add(number)
        }
        _selectedNumbers.value = current
    }

    fun clearSelection() {
        _selectedNumbers.value = emptySet()
    }

    fun quickPick() {
        _selectedNumbers.value = (1..80).shuffled().take(10).toSortedSet()
    }

    fun adjustBet(delta: Double) {
        val newBet = _currentBet.value + delta
        if (newBet >= 1.0 && newBet <= 10000.0) {
            _currentBet.value = newBet
        }
    }

    fun setBet(amount: Double) {
        if (amount in 1.0..10000.0) {
            _currentBet.value = amount
        }
    }

    fun doubleBet() {
        val newBet = _currentBet.value * 2
        if (newBet <= 10000.0) {
            _currentBet.value = newBet
        }
    }

    fun placeBet() {
        val numbers = _selectedNumbers.value.toList()
        if (numbers.isEmpty()) {
            _errorMessage.value = "Please select at least 1 number"
            return
        }

        val result = repository.placeBet(numbers, _currentBet.value)
        result.onSuccess {
            _selectedNumbers.value = emptySet()
            _errorMessage.value = null
        }.onFailure {
            _errorMessage.value = it.message
        }
    }

    fun executeDraw() {
        viewModelScope.launch {
            repository.executeDraw()
            // Check for wins
            userTickets.value.filter { it.status == TicketStatus.WON }.lastOrNull()?.let {
                _showWinDialog.value = it
            }
        }
    }

    fun dismissWinDialog() {
        _showWinDialog.value = null
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun clearError() {
        _errorMessage.value = null
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                val current = repository.timerSeconds.value
                if (current > 0) {
                    // Timer logic handled in repository
                } else {
                    executeDraw()
                }
            }
        }
    }

    fun getHotNumbers(): List<Int> {
        return numberFrequencies.value.filter { it.isHot }.map { it.number }
    }

    fun getColdNumbers(): List<Int> {
        return numberFrequencies.value.filter { it.isCold }.map { it.number }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}

enum class Screen {
    GAME, HISTORY, RESULTS, STATISTICS, LEADERS, DEPOSIT, WITHDRAW, PROFILE, RULES, FAIRNESS
}
