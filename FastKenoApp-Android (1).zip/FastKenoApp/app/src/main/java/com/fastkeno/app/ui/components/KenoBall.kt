package com.fastkeno.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun KenoBall(
    number: Int,
    modifier: Modifier = Modifier,
    isDrawn: Boolean = false,
    isSelected: Boolean = false,
    isHot: Boolean = false,
    isCold: Boolean = false,
    isMatched: Boolean = false,
    onClick: () -> Unit = {}
) {
    val backgroundColor = when {
        isMatched -> Color(0xFF4ADE80)
        isSelected -> Color(0xFF4ADE80)
        isDrawn -> Brush.radialGradient(
            colors = listOf(Color(0xFF2D3748), Color(0xFF1A202C)),
            radius = 50f
        )
        isHot -> Brush.radialGradient(
            colors = listOf(Color(0xFFEF4444), Color(0xFF991B1B)),
            radius = 50f
        )
        isCold -> Brush.radialGradient(
            colors = listOf(Color(0xFF3B82F6), Color(0xFF1E40AF)),
            radius = 50f
        )
        else -> Brush.radialGradient(
            colors = listOf(Color(0xFF2D3748), Color(0xFF1A202C)),
            radius = 50f
        )
    }

    val textColor = when {
        isMatched || isSelected -> Color.Black
        else -> Color.White
    }

    val borderColor = when {
        isMatched -> Color(0xFF22C55E)
        isSelected -> Color(0xFF22C55E)
        isDrawn -> Color(0xFF4A5568)
        isHot -> Color(0xFFEF4444)
        isCold -> Color(0xFF3B82F6)
        else -> Color(0xFF4A5568)
    }

    val scale by animateFloatAsState(
        targetValue = if (isSelected || isMatched) 1.1f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "ball_scale"
    )

    Box(
        modifier = modifier
            .size(40.dp)
            .scale(scale)
            .shadow(4.dp, CircleShape)
            .background(backgroundColor, CircleShape)
            .border(2.dp, borderColor, CircleShape)
            .padding(2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = number.toString(),
            color = textColor,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun DrawnBall(
    number: Int,
    modifier: Modifier = Modifier,
    delayMillis: Int = 0
) {
    var visible by remember { mutableStateOf(false) }

    LaunchedEffect(number) {
        delay(delayMillis.toLong())
        visible = true
    }

    val scale by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(300, easing = FastOutSlowInEasing),
        label = "drawn_ball"
    )

    Box(
        modifier = modifier
            .size(36.dp)
            .scale(scale)
            .shadow(6.dp, CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF3D4F3D), Color(0xFF1A2E1A)),
                    radius = 40f
                ),
                CircleShape
            )
            .border(2.dp, Color(0xFF4A5568), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = number.toString(),
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun AnimatedDrawnBalls(
    numbers: List<Int>,
    modifier: Modifier = Modifier
) {
    FlowRow(
        modifier = modifier.padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        numbers.forEachIndexed { index, number ->
            DrawnBall(
                number = number,
                delayMillis = index * 100
            )
        }
    }
}
