package com.fastkeno.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF4ADE80),
    onPrimary = Color(0xFF000000),
    primaryContainer = Color(0xFF1A3A1A),
    onPrimaryContainer = Color(0xFF4ADE80),
    secondary = Color(0xFFFBBF24),
    onSecondary = Color(0xFF000000),
    background = Color(0xFF0D1F0D),
    onBackground = Color(0xFFFFFFFF),
    surface = Color(0xFF1A2E1A),
    onSurface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFF2D3748),
    onSurfaceVariant = Color(0xFF9CA3AF),
    error = Color(0xFFEF4444),
    onError = Color(0xFFFFFFFF),
    outline = Color(0xFF4A5568)
)

@Composable
fun FastKenoTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
