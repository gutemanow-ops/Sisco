package com.fastkeno.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fastkeno.app.data.NumberFrequency
import com.fastkeno.app.viewmodel.KenoViewModel

@Composable
fun StatisticsScreen(
    viewModel: KenoViewModel
) {
    val numberFrequencies by viewModel.numberFrequencies.collectAsState()
    val hotNumbers = viewModel.getHotNumbers()
    val coldNumbers = viewModel.getColdNumbers()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text(
            text = "Statistics",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Hot numbers section
        StatSection(
            title = "🔥 HOT NUMBERS",
            numbers = hotNumbers.take(10),
            color = Color(0xFFEF4444)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Cold numbers section
        StatSection(
            title = "❄️ COLD NUMBERS",
            numbers = coldNumbers.take(10),
            color = Color(0xFF3B82F6)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Frequency bars
        Text(
            text = "Frequency Distribution",
            color = MaterialTheme.colorScheme.onSurface,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(numberFrequencies.sortedByDescending { it.frequency }.take(20)) { freq ->
                FrequencyBar(frequency = freq)
            }
        }
    }
}

@Composable
fun StatSection(
    title: String,
    numbers: List<Int>,
    color: Color
) {
    Column {
        Text(
            text = title,
            color = color,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            numbers.forEach { number ->
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(color, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = number.toString(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun FrequencyBar(frequency: NumberFrequency) {
    val maxFreq = 50 // Approximate max for scaling
    val progress = (frequency.frequency.toFloat() / maxFreq).coerceIn(0f, 1f)

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = frequency.number.toString().padStart(2, '0'),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp,
            modifier = Modifier.width(28.dp)
        )

        Box(
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(progress)
                    .height(8.dp)
                    .background(
                        when {
                            frequency.isHot -> Color(0xFFEF4444)
                            frequency.isCold -> Color(0xFF3B82F6)
                            else -> MaterialTheme.colorScheme.primary
                        },
                        RoundedCornerShape(4.dp)
                    )
            )
        }

        Text(
            text = frequency.frequency.toString(),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp,
            modifier = Modifier.width(24.dp)
        )
    }
}
