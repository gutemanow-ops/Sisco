package com.fastkeno.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fastkeno.app.viewmodel.KenoViewModel

@Composable
fun DepositScreen(
    viewModel: KenoViewModel
) {
    var selectedMethod by remember { mutableStateOf<String?>(null) }
    var amount by remember { mutableStateOf("100") }
    var transactionNumber by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text(
            text = "DEPOSIT METHODS",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        // Telebirr option
        PaymentMethodCard(
            name = "Telebirr P2P",
            selected = selectedMethod == "telebirr",
            onClick = { selectedMethod = "telebirr" }
        )

        Spacer(modifier = Modifier.height(8.dp))

        PaymentMethodCard(
            name = "Telebirr P2P (Alternative)",
            selected = selectedMethod == "telebirr2",
            onClick = { selectedMethod = "telebirr2" }
        )

        if (selectedMethod != null) {
            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Amount",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 14.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it.filter { c -> c.isDigit() } },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = Color(0xFF4A5568),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                suffix = { Text("ETB", color = Color(0xFF9CA3AF)) }
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Transaction Number",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 14.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            OutlinedTextField(
                value = transactionNumber,
                onValueChange = { transactionNumber = it },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = Color(0xFF4A5568),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                placeholder = { Text("Paste transaction number", color = Color(0xFF4A5568)) }
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { /* Process deposit */ },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF22C55E)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "Confirm Deposit",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun PaymentMethodCard(
    name: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                if (selected) Color(0xFF1A3A1A) else Color(0xFF1A2E1A),
                RoundedCornerShape(8.dp)
            )
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) MaterialTheme.colorScheme.primary else Color(0xFF4A5568),
                shape = RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onClick)
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(Color.White, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("📱", fontSize = 20.sp)
            }
            Text(
                text = name,
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
