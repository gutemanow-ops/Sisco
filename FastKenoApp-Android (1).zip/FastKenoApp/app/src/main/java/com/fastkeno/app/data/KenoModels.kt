package com.fastkeno.app.data

import java.util.UUID

data class KenoDraw(
    val drawId: String,
    val timestamp: Long,
    val numbers: List<Int>,
    val serverSeedHash: String,
    val revealedServerSeed: String? = null,
    val clientSeed: String = "",
    val nonce: Int = 0
) {
    fun getFormattedNumbers(): String = numbers.sorted().joinToString(", ")
}

data class KenoTicket(
    val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val drawId: String,
    val selectedNumbers: List<Int>,
    val betAmount: Double,
    val potentialWin: Double = 0.0,
    val actualWin: Double? = null,
    val status: TicketStatus = TicketStatus.PENDING,
    val matchedNumbers: List<Int> = emptyList(),
    val timestamp: Long = System.currentTimeMillis()
) {
    fun getMaskedId(): String = "${'$'}{userId.take(1)}***${'$'}{userId.last()}"
}

enum class TicketStatus {
    PENDING,
    WON,
    LOST,
    CANCELLED
}

data class User(
    val id: String,
    val username: String,
    val balance: Double = 0.0,
    val totalBets: Int = 0,
    val totalWins: Int = 0,
    val totalWinnings: Double = 0.0
)

data class NumberFrequency(
    val number: Int,
    val frequency: Int,
    val isHot: Boolean = false,
    val isCold: Boolean = false
)

data class LeaderboardEntry(
    val rank: Int,
    val userId: String,
    val betAmount: Double,
    val winAmount: Double
)

data class PaymentMethod(
    val id: String,
    val name: String,
    val icon: String,
    val minAmount: Double,
    val maxAmount: Double,
    val isActive: Boolean = true
)

data class Transaction(
    val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val type: TransactionType,
    val amount: Double,
    val status: TransactionStatus = TransactionStatus.PENDING,
    val paymentMethod: String,
    val referenceNumber: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

enum class TransactionType {
    DEPOSIT,
    WITHDRAW
}

enum class TransactionStatus {
    PENDING,
    COMPLETED,
    FAILED,
    CANCELLED
}

// Payout table based on the screenshot
object PayoutTable {
    // Maps [spots picked] to [matches -> multiplier]
    private val payouts = mapOf(
        1 to mapOf(0 to 0.0, 1 to 3.5),
        2 to mapOf(0 to 0.0, 1 to 1.0, 2 to 10.0),
        3 to mapOf(0 to 0.0, 1 to 0.0, 2 to 2.0, 3 to 50.0),
        4 to mapOf(0 to 0.0, 1 to 0.0, 2 to 1.5, 3 to 10.0, 4 to 80.0),
        5 to mapOf(0 to 0.0, 1 to 0.0, 2 to 1.0, 3 to 3.0, 4 to 30.0, 5 to 150.0),
        6 to mapOf(0 to 0.0, 1 to 0.0, 2 to 0.0, 3 to 2.0, 4 to 15.0, 5 to 60.0, 6 to 500.0),
        7 to mapOf(0 to 0.0, 1 to 0.0, 2 to 0.0, 3 to 2.0, 4 to 4.0, 5 to 20.0, 6 to 80.0, 7 to 1000.0),
        8 to mapOf(0 to 0.0, 1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 5.0, 5 to 15.0, 6 to 50.0, 7 to 200.0, 8 to 2000.0),
        9 to mapOf(0 to 0.0, 1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 2.0, 5 to 10.0, 6 to 25.0, 7 to 125.0, 8 to 1000.0, 9 to 5000.0),
        10 to mapOf(0 to 0.0, 1 to 0.0, 2 to 0.0, 3 to 0.0, 4 to 0.0, 5 to 5.0, 6 to 30.0, 7 to 100.0, 8 to 300.0, 9 to 2000.0, 10 to 10000.0)
    )

    fun getMultiplier(spots: Int, matches: Int): Double {
        return payouts[spots]?.get(matches) ?: 0.0
    }

    fun calculateWin(spots: Int, matches: Int, betAmount: Double): Double {
        val multiplier = getMultiplier(spots, matches)
        return if (multiplier > 0) betAmount * multiplier else 0.0
    }
}
