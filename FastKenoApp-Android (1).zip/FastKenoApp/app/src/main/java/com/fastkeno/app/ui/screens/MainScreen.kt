package com.fastkeno.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import com.fastkeno.app.viewmodel.KenoViewModel
import com.fastkeno.app.viewmodel.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: KenoViewModel = hiltViewModel()
) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "FAST KENO",
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.headlineMedium
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            BottomNavigationBar(
                currentScreen = currentScreen,
                onNavigate = { viewModel.navigateTo(it) }
            )
        }
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            when (currentScreen) {
                Screen.GAME -> GameScreen(viewModel = viewModel)
                Screen.HISTORY -> HistoryScreen(viewModel = viewModel)
                Screen.RESULTS -> ResultsScreen(viewModel = viewModel)
                Screen.STATISTICS -> StatisticsScreen(viewModel = viewModel)
                Screen.LEADERS -> LeadersScreen(viewModel = viewModel)
                Screen.DEPOSIT -> DepositScreen(viewModel = viewModel)
                Screen.WITHDRAW -> WithdrawScreen(viewModel = viewModel)
                Screen.PROFILE -> ProfileScreen(viewModel = viewModel)
                Screen.RULES -> RulesScreen()
                Screen.FAIRNESS -> FairnessScreen()
            }
        }
    }
}

@Composable
fun BottomNavigationBar(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        NavigationBarItem(
            icon = { Text("▶", fontSize = 20.sp) },
            label = { Text("GAME") },
            selected = currentScreen == Screen.GAME,
            onClick = { onNavigate(Screen.GAME) }
        )
        NavigationBarItem(
            icon = { Text("↻", fontSize = 20.sp) },
            label = { Text("HISTORY") },
            selected = currentScreen == Screen.HISTORY,
            onClick = { onNavigate(Screen.HISTORY) }
        )
        NavigationBarItem(
            icon = { Text("✓", fontSize = 20.sp) },
            label = { Text("RESULTS") },
            selected = currentScreen == Screen.RESULTS,
            onClick = { onNavigate(Screen.RESULTS) }
        )
        NavigationBarItem(
            icon = { Text("📊", fontSize = 20.sp) },
            label = { Text("STATS") },
            selected = currentScreen == Screen.STATISTICS,
            onClick = { onNavigate(Screen.STATISTICS) }
        )
        NavigationBarItem(
            icon = { Text("👤", fontSize = 20.sp) },
            label = { Text("PROFILE") },
            selected = currentScreen == Screen.PROFILE,
            onClick = { onNavigate(Screen.PROFILE) }
        )
    }
}
