# Fast Keno 🎱

[![Android CI](https://github.com/yourusername/fastkeno/actions/workflows/android.yml/badge.svg)](https://github.com/yourusername/fastkeno/actions/workflows/android.yml)
[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![F-Droid](https://img.shields.io/f-droid/v/com.fastkeno.app.svg)](https://f-droid.org/packages/com.fastkeno.app/)

A provably fair **Keno lottery game** for Android, built with Kotlin and Jetpack Compose.

## 📱 Screenshots

| Game Screen | Results | Statistics | Leaderboard |
|-------------|---------|------------|-------------|
| ![Game](screenshots/game.png) | ![Results](screenshots/results.png) | ![Stats](screenshots/stats.png) | ![Leaders](screenshots/leaders.png) |

## 🎮 How to Play

1. **Choose 1-10 numbers** from 1 to 80 on the number grid
2. **Set your bet amount** (1 - 10,000 ETB)
3. **Click BET** to place your ticket
4. **Wait for the draw** - 20 numbers are drawn every round
5. **Win based on matches** - payouts range from 1x to 10,000x

## ✨ Features

- 🎯 **Provably Fair**: SHA-512 hash verification for every draw
- 🔥 **Hot/Cold Numbers**: Visual indicators for frequently drawn numbers
- 📊 **Statistics**: Track number frequencies over last 100 rounds
- 🏆 **Leaderboard**: See top winners
- 💰 **Telebirr P2P**: Deposit and withdraw using Telebirr (Ethiopia)
- 📈 **97% RTP** (Return to Player)
- 💎 **Max Win**: 80,000 ETB

## 🏗️ Tech Stack

- **Language**: Kotlin
- **UI**: Jetpack Compose
- **Architecture**: MVVM + Repository Pattern
- **DI**: Hilt
- **Networking**: Retrofit + OkHttp
- **State Management**: Kotlin Coroutines + Flow
- **Build**: Gradle with Kotlin DSL

## 📥 Installation

### F-Droid
```
https://f-droid.org/packages/com.fastkeno.app/
```

### GitHub Releases
Download the latest APK from [Releases](https://github.com/yourusername/fastkeno/releases)

### Build from Source
```bash
git clone https://github.com/yourusername/fastkeno.git
cd fastkeno
./gradlew assembleDebug
```

## 🎲 Game Rules

- Each round lasts **one minute**
- **20 numbers** are drawn from 1-80 using cryptographically secure RNG
- Choose **1-10 numbers** per ticket
- Winning combinations have corresponding odds multiplied by bet amount
- See in-app **Rules** screen for full payout table

## 🔐 Fairness

The game uses a **provably fair** system:
- **Server Seed (Salt)**: Generated before each round, hash published
- **Client Seed**: Provided by player or system
- **SHA-512 Hash**: Verifiable result computation
- Players can independently verify every draw

## 💳 Payment Methods

- **Telebirr P2P** (Ethiopia)
- Minimum deposit: 10 ETB
- Minimum withdrawal: 100 ETB

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the **GNU General Public License v3.0** - see [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Atlas-V Gaming for the original game concept
- Ethiopian Telebirr for payment integration
- F-Droid community for open-source distribution

---

**⚠️ Disclaimer**: This is a gambling game. Please play responsibly. 18+ only.
